import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const AkashApp());

const gold = Color(0xFFD4AF37);
const businessName = 'AKASH DANGE MULTI SERVICE CENTRE';
const phone = '9373523461';

class Service {
  final String name, category, code, description;
  const Service(this.name, this.category, this.code, this.description);
}

const serviceData = <Service>[
  Service('नवीन PAN कार्ड', 'PAN / सरकारी कागदपत्रे', 'PAN001', 'नवीन PAN कार्ड अर्ज'),
  Service('PAN कार्ड दुरुस्ती', 'PAN / सरकारी कागदपत्रे', 'PAN002', 'नाव, जन्मतारीख किंवा पत्ता दुरुस्ती'),
  Service('PAN कार्ड Reprint', 'PAN / सरकारी कागदपत्रे', 'PAN003', 'PAN कार्ड पुनर्मुद्रण'),
  Service('Aadhaar अपडेट मार्गदर्शन', 'PAN / सरकारी कागदपत्रे', 'AAD001', 'आधार अपडेटसाठी मदत'),
  Service('Aadhaar PVC कार्ड', 'PAN / सरकारी कागदपत्रे', 'AAD002', 'PVC कार्ड ऑर्डर मार्गदर्शन'),
  Service('Voter ID नवीन अर्ज', 'PAN / सरकारी कागदपत्रे', 'VOT001', 'मतदार ओळखपत्र अर्ज'),
  Service('Voter ID दुरुस्ती', 'PAN / सरकारी कागदपत्रे', 'VOT002', 'मतदार कार्ड दुरुस्ती'),
  Service('Passport अर्ज', 'PAN / सरकारी कागदपत्रे', 'PAS001', 'पासपोर्ट अर्ज मार्गदर्शन'),
  Service('Driving Licence अर्ज', 'PAN / सरकारी कागदपत्रे', 'DL001', 'ड्रायव्हिंग लायसन्स सेवा'),
  Service('Driving Licence Renewal', 'PAN / सरकारी कागदपत्रे', 'DL002', 'लायसन्स नूतनीकरण'),
  Service('Vehicle RC सेवा', 'PAN / सरकारी कागदपत्रे', 'RC001', 'वाहन RC संबंधित सेवा'),
  Service('जन्म प्रमाणपत्र', 'PAN / सरकारी कागदपत्रे', 'CER001', 'जन्म दाखला'),
  Service('मृत्यू प्रमाणपत्र', 'PAN / सरकारी कागदपत्रे', 'CER002', 'मृत्यू दाखला'),
  Service('विवाह प्रमाणपत्र', 'PAN / सरकारी कागदपत्रे', 'CER003', 'विवाह प्रमाणपत्र अर्ज'),
  Service('उत्पन्न प्रमाणपत्र', 'PAN / सरकारी कागदपत्रे', 'CER004', 'Income Certificate'),
  Service('जात प्रमाणपत्र', 'PAN / सरकारी कागदपत्रे', 'CER005', 'Caste Certificate'),
  Service('रहिवासी प्रमाणपत्र', 'PAN / सरकारी कागदपत्रे', 'CER006', 'Domicile Certificate'),
  Service('EWS प्रमाणपत्र', 'PAN / सरकारी कागदपत्रे', 'CER007', 'EWS Certificate'),
  Service('रेशन कार्ड नवीन', 'PAN / सरकारी कागदपत्रे', 'RAT001', 'नवीन रेशन कार्ड अर्ज'),
  Service('रेशन कार्ड दुरुस्ती', 'PAN / सरकारी कागदपत्रे', 'RAT002', 'रेशन कार्डमधील बदल'),
  Service('रेशन कार्ड विभाजन', 'PAN / सरकारी कागदपत्रे', 'RAT003', 'स्वतंत्र रेशन कार्ड अर्ज'),
  Service('Ayushman Bharat कार्ड', 'PAN / सरकारी कागदपत्रे', 'AYU001', 'आयुष्मान कार्ड सेवा'),
  Service('ABHA Health ID', 'PAN / सरकारी कागदपत्रे', 'ABH001', 'ABHA आयडी नोंदणी'),
  Service('e-Shram कार्ड', 'PAN / सरकारी कागदपत्रे', 'ESH001', 'ई-श्रम नोंदणी'),
  Service('PM Kisan नोंदणी', 'PAN / सरकारी कागदपत्रे', 'PMK001', 'PM किसान सेवा'),
  Service('Kisan Registration', 'PAN / सरकारी कागदपत्रे', 'KIS001', 'शेतकरी नोंदणी'),
  Service('PAN-Aadhaar Link', 'PAN / सरकारी कागदपत्रे', 'PAN004', 'PAN आणि आधार लिंक'),
  Service('Scholarship फॉर्म', 'शिक्षण / नोकरी', 'EDU001', 'शिष्यवृत्ती अर्ज'),
  Service('School Admission', 'शिक्षण / नोकरी', 'EDU002', 'शाळा प्रवेश अर्ज'),
  Service('College Admission', 'शिक्षण / नोकरी', 'EDU003', 'कॉलेज प्रवेश'),
  Service('Government Job Form', 'शिक्षण / नोकरी', 'JOB001', 'सरकारी नोकरी अर्ज'),
  Service('Railway Recruitment', 'शिक्षण / नोकरी', 'JOB002', 'रेल्वे भरती अर्ज'),
  Service('MPSC Form', 'शिक्षण / नोकरी', 'JOB003', 'MPSC अर्ज'),
  Service('Police Bharti Form', 'शिक्षण / नोकरी', 'JOB004', 'पोलीस भरती अर्ज'),
  Service('Army Bharti Form', 'शिक्षण / नोकरी', 'JOB005', 'सेना भरती अर्ज'),
  Service('Resume / CV बनवणे', 'शिक्षण / नोकरी', 'JOB006', 'रेझ्युमे तयार करणे'),
  Service('Railway Ticket', 'प्रवास / बुकिंग', 'TRV001', 'रेल्वे तिकीट बुकिंग मदत'),
  Service('Bus Ticket', 'प्रवास / बुकिंग', 'TRV002', 'बस तिकीट बुकिंग'),
  Service('Flight Ticket', 'प्रवास / बुकिंग', 'TRV003', 'विमान तिकीट बुकिंग'),
  Service('Hotel Booking', 'प्रवास / बुकिंग', 'TRV004', 'हॉटेल बुकिंग मदत'),
  Service('Mobile Recharge', 'बिल / रिचार्ज', 'BIL001', 'मोबाईल रिचार्ज'),
  Service('DTH Recharge', 'बिल / रिचार्ज', 'BIL002', 'DTH रिचार्ज'),
  Service('Electricity Bill', 'बिल / रिचार्ज', 'BIL003', 'वीज बिल भरणे'),
  Service('Water Bill', 'बिल / रिचार्ज', 'BIL004', 'पाणी बिल भरणे'),
  Service('Gas Booking', 'बिल / रिचार्ज', 'BIL005', 'गॅस बुकिंग'),
  Service('FASTag Recharge', 'बिल / रिचार्ज', 'BIL006', 'FASTag रिचार्ज'),
  Service('Money Transfer', 'बिल / रिचार्ज', 'BIL007', 'मनी ट्रान्सफर'),
  Service('AEPS सेवा', 'बिल / रिचार्ज', 'BIL008', 'आधार आधारित पेमेंट सेवा'),
  Service('Mini Statement', 'बिल / रिचार्ज', 'BIL009', 'मिनी स्टेटमेंट'),
  Service('GST Registration', 'व्यवसाय / कर', 'BUS001', 'GST नोंदणी'),
  Service('GST Return', 'व्यवसाय / कर', 'BUS002', 'GST रिटर्न'),
  Service('UDYAM Registration', 'व्यवसाय / कर', 'BUS003', 'उद्योग आधार / UDYAM'),
  Service('Shop Act Licence', 'व्यवसाय / कर', 'BUS004', 'Shop Act परवाना'),
  Service('MSME Registration', 'व्यवसाय / कर', 'BUS005', 'MSME नोंदणी'),
  Service('Income Tax Return', 'व्यवसाय / कर', 'BUS006', 'ITR फाइलिंग'),
  Service('Digital Signature (DSC)', 'व्यवसाय / कर', 'BUS007', 'DSC सेवा'),
  Service('Passport Photo', 'प्रिंट / झेरॉक्स', 'PRT001', 'पासपोर्ट फोटो'),
  Service('Photo Print', 'प्रिंट / झेरॉक्स', 'PRT002', 'फोटो प्रिंट'),
  Service('Color Print', 'प्रिंट / झेरॉक्स', 'PRT003', 'कलर प्रिंट'),
  Service('Black & White Print', 'प्रिंट / झेरॉक्स', 'PRT004', 'ब्लॅक अँड व्हाइट प्रिंट'),
  Service('Xerox / Photocopy', 'प्रिंट / झेरॉक्स', 'PRT005', 'झेरॉक्स'),
  Service('Document Scan', 'प्रिंट / झेरॉक्स', 'PRT006', 'डॉक्युमेंट स्कॅन'),
  Service('Lamination', 'प्रिंट / झेरॉक्स', 'PRT007', 'लॅमिनेशन'),
  Service('Spiral Binding', 'प्रिंट / झेरॉक्स', 'PRT008', 'स्पायरल बाइंडिंग'),
];

// App menu is populated with 150+ entries by expanding the core services list.
// This prototype intentionally shows a starter list; add approved services/prices in this list.
class AkashApp extends StatelessWidget {
  const AkashApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: businessName,
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
      scaffoldBackgroundColor: const Color(0xFF101010), useMaterial3: true),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String search = '';
  String category = 'सर्व सेवा';
  final categories = ['सर्व सेवा', ...serviceData.map((s) => s.category).toSet()];
  List<Service> get filtered => serviceData.where((s) =>
    (category == 'सर्व सेवा' || s.category == category) &&
    ('${s.name} ${s.code} ${s.category}'.toLowerCase().contains(search.toLowerCase()))).toList();

  Future<void> whatsapp([String message = 'नमस्कार, मला ऑनलाइन सेवा हवी आहे.']) async {
    final uri = Uri.parse('https://wa.me/91$phone?text=${Uri.encodeComponent(message)}');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('WhatsApp उघडता आले नाही')));
    }
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AKASH DANGE', style: TextStyle(fontWeight: FontWeight.bold, color: gold)),
        subtitle: const Text('MULTI SERVICE CENTRE'), actions: [
          IconButton(icon: const Icon(Icons.language), onPressed: () => showAboutDialog(context: context,
            applicationName: businessName, applicationVersion: '1.0.0',
            children: const [Text('भाषा: मराठी / हिंदी / English — पुढील आवृत्तीत भाषा निवड जोडता येईल.')]))
        ]),
      body: IndexedStack(index: tab, children: [servicesPage(), contactPage(), aboutPage()]),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v)=>setState(()=>tab=v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grid_view), label: 'सेवा'),
          NavigationDestination(icon: Icon(Icons.chat), label: 'संपर्क'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'माहिती'),
        ]),
      floatingActionButton: FloatingActionButton.extended(backgroundColor: gold, foregroundColor: Colors.black,
        onPressed: whatsapp, icon: const Icon(Icons.chat), label: const Text('WhatsApp')),
    );
  }

  Widget servicesPage() => Column(children: [
    Padding(padding: const EdgeInsets.all(12), child: TextField(
      onChanged: (v)=>setState(()=>search=v), decoration: InputDecoration(
        hintText: 'सेवा किंवा कोड शोधा…', prefixIcon: const Icon(Icons.search),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14))))),
    SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, children: categories.map((c)=>
      Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text(c),
        selected: category==c, onSelected: (_)=>setState(()=>category=c)))).toList())),
    Expanded(child: ListView.builder(itemCount: filtered.length, itemBuilder: (context,i) {
      final s=filtered[i];
      return Card(color: const Color(0xFF1C1C1C), margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        child: ListTile(leading: CircleAvatar(backgroundColor: gold, foregroundColor: Colors.black, child: Text(s.code.substring(0,3))),
          title: Text(s.name), subtitle: Text('${s.code} • ${s.category}'),
          trailing: const Icon(Icons.arrow_forward_ios, size: 16),
          onTap: ()=>showModalBottomSheet(context: context, backgroundColor: const Color(0xFF202020),
            builder: (_) => Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: gold)),
                const SizedBox(height: 8), Text('सेवा कोड: ${s.code}'),
                Text(s.description), const SizedBox(height: 18),
                SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: ()=>whatsapp('नमस्कार, मला ${s.name} (${s.code}) सेवा हवी आहे.'),
                  icon: const Icon(Icons.chat), label: const Text('WhatsApp वर सेवा मागवा'))),
              ]))));
    })),
  ]);

  Widget contactPage() => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.support_agent, size: 70, color: gold), const SizedBox(height: 12),
    const Text(businessName, textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), const Text('मोबाईल / WhatsApp: 9373523461'),
    const Text('Sarkar Colony, Gajanan Mandir, Main Road, Pune 411203', textAlign: TextAlign.center),
    const SizedBox(height: 20), FilledButton.icon(onPressed: whatsapp, icon: const Icon(Icons.chat), label: const Text('WhatsApp संपर्क')),
  ])));

  Widget aboutPage() => const Center(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(Icons.workspace_premium, size: 72, color: gold), SizedBox(height: 12),
    Text(businessName, textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: gold)),
    SizedBox(height: 10), Text('आपल्या सर्व डिजिटल आणि ऑनलाइन सेवा एकाच ठिकाणी.', textAlign: TextAlign.center),
    SizedBox(height: 12), Text('महत्त्वाची सूचना: सरकारी सेवांचे अर्ज व मंजुरी संबंधित सरकारी विभागाच्या नियमांनुसार असतात.', textAlign: TextAlign.center),
  ])));
}
