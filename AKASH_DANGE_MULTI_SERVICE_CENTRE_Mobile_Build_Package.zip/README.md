# AKASH DANGE MULTI SERVICE CENTRE — Flutter Starter

## Included
- Flutter Android + iOS starter app
- Marathi services, service codes, search and category filters
- Service detail sheet and WhatsApp request link
- Contact / About pages

## Setup
1. Install Flutter SDK and Android Studio.
2. Extract this ZIP.
3. In this folder run:
   ```bash
   flutter pub get
   flutter run
   ```
4. Android APK:
   ```bash
   flutter build apk --release
   ```
   APK: `build/app/outputs/flutter-apk/app-release.apk`
5. iOS (requires macOS + Xcode):
   ```bash
   flutter build ios
   ```
   Open `ios/Runner.xcworkspace` in Xcode, configure signing, then archive/publish.

## Important
This is a frontend starter / prototype. It does not yet include a production backend, customer authentication, real admin panel, payment gateway, database, or live government-service integrations. Those require server setup, credentials, and compliance checks. Add/verify service listings and official eligibility/document requirements before publishing.
